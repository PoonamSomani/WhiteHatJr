import {ToDo} from '../model/ToDo';
export const defaultToDoList = [{
    text: 'Hit the gym',
    id: 1
},{
    text: 'Pay bills',
    id: 2
},{
    text: 'Meet George',
    id: 3
},{
    text: 'Buy eggs',
    id: 4
},{
    text: 'Read a book',
    id: 5
},{
    text: 'Organize office',
    id: 6
}]
