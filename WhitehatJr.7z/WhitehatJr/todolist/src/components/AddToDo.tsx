import React, { FunctionComponent, useState } from 'react';
import logo from './logo.svg';
//import './ToDoList.css';

interface props {
    addNewItem : (newItem: String) => void
}
const AddToDo : FunctionComponent<props> = ({
    addNewItem
}
) =>  {
    const [newItem, setNewItem] = useState<String>("");
    const saveItemValue = (newItem: any) => {
        //save to state
        setNewItem(newItem);
    }
    const addNewItemToList = () => {
        // add the item in state to top of todo list
        addNewItem(newItem);

    }
  return (
   <div>
       <input type="text" placeholder="Title..."  onClick={(value) => saveItemValue(value)} />
       <button onClick={addNewItemToList}> Add </button>
    </div>
  );
}

export default AddToDo;
