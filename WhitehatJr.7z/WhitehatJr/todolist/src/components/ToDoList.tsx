import React, { useEffect, useState } from 'react';
import logo from './logo.svg';
import {defaultToDoList} from '../utils/toDoListHelper';
import {ToDo} from '../model/ToDo';
import AddToDo from './AddToDo';
import ListToDo from './ListToDo';
//import './ToDoList.css';

function ToDoList() {
    const [toDoList, setToDoList] = useState<any>([]);
    // for the first time only, fetch the list of todo from utils
    useEffect (() => {
        setToDoList(defaultToDoList);
    }, [])

    const addNewItem = (newItem: any) => {
        const toDoListClone = [...toDoList];
        toDoListClone.unshift({text: newItem.target.value, id: toDoListClone.length});
        setToDoList(toDoListClone);
    }
  return (
   <div>
       <AddToDo addNewItem = {addNewItem}/>
       <ListToDo toDoList = {toDoList}/>
    </div>
  );
}

export default ToDoList;
