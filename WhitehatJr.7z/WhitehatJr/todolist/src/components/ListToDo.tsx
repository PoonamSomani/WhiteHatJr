import React, {FunctionComponent,  useState } from 'react';
import logo from './logo.svg';
import {ToDo} from '../model/ToDo';
//import './ToDoList.css';
interface props{
    toDoList: any
}
const ListToDo : FunctionComponent<props> = ({
    toDoList
}) => {
    
  return (
   <div>
      {toDoList.map((toDo: any) => {
          return (<div> {toDo.text} </div>);
      }
      )}
    </div>
  );
}

export default ListToDo;
