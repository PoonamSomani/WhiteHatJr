export class ToDo{
    public text: String;
    public id: Number;

    constructor(copy: ToDo){
        this.text = copy.text;
        this.id = copy.id;
    }
}
