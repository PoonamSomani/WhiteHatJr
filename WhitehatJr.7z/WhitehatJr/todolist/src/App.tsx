import React from 'react';
import logo from './logo.svg';
import ToDoList from './components/ToDoList';
import './App.css';

function App() {
  return (
    <div className="App">
      <header>
        <ToDoList/>
      </header>
    </div>
  );
}

export default App;
